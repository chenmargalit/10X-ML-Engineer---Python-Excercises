Utils is a folder you usually put util functions, e.g. helper functions that are being used in many places.
For example if you create a request validation function, it might go here. 