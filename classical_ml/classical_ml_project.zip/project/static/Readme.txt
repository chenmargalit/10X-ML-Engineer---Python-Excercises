Used for any static text you might want to use. For example:

MODEL_NAME = 'model_name'

This should be a Python file that contains something like the above string. In your code you import MODEL_NAME.